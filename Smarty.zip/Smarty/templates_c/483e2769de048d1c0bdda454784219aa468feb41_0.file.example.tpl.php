<?php
/* Smarty version 3.1.30, created on 2017-03-01 09:39:02
  from "D:\wamp\www\Smarty\templates\example.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58b688a6882b62_44745909',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '483e2769de048d1c0bdda454784219aa468feb41' => 
    array (
      0 => 'D:\\wamp\\www\\Smarty\\templates\\example.tpl',
      1 => 1488357531,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58b688a6882b62_44745909 (Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['smarty']->value;
}
}
